//
//  CardGamePrototypeApp.swift
//  CardGamePrototype
//
//  Created by Rafiq Rifhan Rosman on 2024/06/20.
//

import SwiftUI

struct CardGamePrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
