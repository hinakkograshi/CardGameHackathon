//
//  ContentView.swift
//  CardGamePrototype
//
//  Created by Rafiq Rifhan Rosman on 2024/06/20.
//

import SwiftUI

struct Card: Identifiable {
    let id = UUID()
    var value: String
    var isFlipped: Bool = false
    let isTargeted: Bool = false
}

struct HintValue {
    var hintValue: ((Card) -> Int)?

    init() {
        self.hintValue = { card in
            if card.value != "bomb"{
                let number = Int(card.value)
                guard number! < 10 else {
                    return number! // If the number is already 10 or more, return it unchanged
                }
                //let maxValue = 10 - number!
                return Int.random(in: 1..<number!)
            }else {
                return Int.random(in: 1..<9)
            }
        }
    }
}



struct Unlocks: Identifiable {
    let id = UUID()
    var isUnlocked: Bool = false
}

struct CardView: View {
    @Binding var card: Card
    @State var isTapped: Bool = false
    @State var isCardTargeted: Bool = false
    @State var isHintDropped: Bool = false
    let hintVal = HintValue().hintValue

    
    var body: some View {
        ZStack {
            if card.isFlipped {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.blue)
                    .frame(width: 80, height: 120)
                    .overlay(Text(card.value).foregroundColor(.white))
            } else {
                RoundedRectangle(cornerRadius: 10)
                    .fill(isCardTargeted ? Color.green : Color.gray)
                    .frame(width: 80, height: 120)
                    .overlay(isHintDropped ? Text("\( hintVal!(card))+").foregroundColor(.white).bold() : Text(""))
            }
        }
        .onTapGesture {
            if !isTapped {
                withAnimation {
                    card.isFlipped.toggle()
                    isTapped = true
                }
            }
        }
        .dropDestination(for: Image.self) { droppedHints, location in
            isHintDropped = true
            return true
        } isTargeted: { isTargeted in
            isCardTargeted = isTargeted
        }
    
    }
}

struct ContentView: View {
    // define a 3x3 array of Card
    @State private var cards: [[Card]] = Array(repeating: Array(repeating: Card(value: ""), count: 3), count: 3)
    @State private var isUnlocked1: Bool = false
    @State private var isUnlocked2: Bool = false
    @State private var isUnlocked3: Bool = false
    @State private var isUnlocked4: Bool = false
    @State private var isUnlocked5: Bool = false
    @State private var isUnlocked6: Bool = false
    
    var body: some View {
        HStack {
            Image(systemName: "questionmark.app.fill")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 30, height: 30)
                .foregroundColor(.purple)
            VStack {
                HStack(spacing: 68) {
                    // First Medical Icon
                    let medicalIcon = Image(systemName: "plusminus.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 30, height: 30)
                        .foregroundColor(isUnlocked1 ? .yellow : .red)

                    if isUnlocked1 {
                        medicalIcon.draggable(Image(systemName: "plusminus.circle"))
                    } else {
                        medicalIcon
                    }
                    
                    // Second Medical Icon
                    let medicalIcon2 = Image(systemName: "plusminus.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 30, height: 30)
                        .foregroundColor(isUnlocked2 ? .yellow : .red)

                    if isUnlocked2 {
                        medicalIcon2.draggable(Image(systemName: "plusminus.circle"))
                    } else {
                        medicalIcon2
                    }
                    // Third Medical Icon
                    let medicalIcon3 = Image(systemName: "plusminus.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 30, height: 30)
                        .foregroundColor(isUnlocked3 ? .yellow : .red)

                    if isUnlocked3 {
                        medicalIcon3.draggable(Image(systemName: "plusminus.circle"))
                    } else {
                        medicalIcon3
                    }
                }
                .frame(maxWidth: .infinity)
   
                
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 10) {
                    ForEach(0..<3) { row in
                        ForEach(0..<3) { col in
                            CardView(card: $cards[row][col])
                                .onChange(of: cards[row][col].isFlipped) { _, _ in
                                    checkForUnlock()
                                }
                        }
                    }
                }
            }
            VStack(spacing: 95) {
                Image(systemName: "plusminus.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
                    .foregroundColor(isUnlocked4 ? .yellow : .red)
                    .draggable(Image(systemName: "plusminus.circle"))
                
                // Second Medical Icon
                Image(systemName: "plusminus.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
                    .foregroundColor(isUnlocked5 ? .yellow : .blue)
                    .draggable(Image(systemName: "plusminus.circle"))
                
                
                // Third Medical Icon
                Image(systemName: "plusminus.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
                    .foregroundColor(isUnlocked6 ? .yellow : .green)
                    .draggable(Image(systemName: "plusminus.circle"))
            }
        }
        .padding()
        .onAppear {
            generateCards()
        }
    }
    
    // Function to generate random values for the cards
    private func generateCards() {
        // Create an array of values from 2 to 9 and add "bomb"
        var values = (2...9).map { "\($0)" }
        values.append("bomb")

        // Shuffle the array to randomize the order
        values.shuffle()

        var index = 0
                for row in 0..<3 {
                    for col in 0..<3 {
                        cards[row][col] = Card(value: values[index])
                        index += 1
                    }
                }
    }
    
    private func checkForUnlock() {
        // Check rows
        if cards[0][0].isFlipped && cards[0][1].isFlipped && cards[0][2].isFlipped {
            isUnlocked4.toggle()
        }
        
        if cards[1][0].isFlipped && cards[1][1].isFlipped && cards[1][2].isFlipped {
            isUnlocked5.toggle()
        }
        
        if cards[2][0].isFlipped && cards[2][1].isFlipped && cards[2][2].isFlipped {
            isUnlocked6.toggle()
        }
        // Check columns
        if cards[0][0].isFlipped && cards[1][0].isFlipped && cards[2][0].isFlipped {
            isUnlocked1.toggle()
        }
        
        if cards[0][1].isFlipped && cards[1][1].isFlipped && cards[2][1].isFlipped {
            isUnlocked2.toggle()
        }
        
        if cards[0][2].isFlipped && cards[1][2].isFlipped && cards[2][2].isFlipped {
            isUnlocked3.toggle()
        }
    }
    
    private func unlockAbility() {
        // Implement ability unlocking logic here
        print("Ability Unlocked!")
    }
}



@main
struct CardGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


#Preview {
    ContentView()
}
